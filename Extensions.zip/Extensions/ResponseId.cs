public enum ResponseId
{
    None,
    Hit,
    Miss,
    FalseAlarm,
    CorrectRejection,
    PullPenalty,
    EarlyResponse
}