public enum StateId
{
    ITI,

    Tone,

    Annotation,

    Joystick,
    Lick,
    Blink,


    Hit,
    Miss,
    FalseAlarm,
    CorrectRejection,
    PullPenalty,
    EarlyResponse
}